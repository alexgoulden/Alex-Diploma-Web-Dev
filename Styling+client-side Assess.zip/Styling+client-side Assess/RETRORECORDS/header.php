    <header>
        <a href="index.php"><img id="logo-title" alt="logo" src="images/retroRecordsNewtown_logo.png"></a>
        <a href="index.php"><img class="record" alt="spinning record" src="images/record.svg"></a>
        <a class="header-links" href="retro.php" id="hl1">Records</a>
        <a class="header-links" href="about.php" id="hl4">About Us</a>
        <a id="hl5" class="header-links" href="contact.php">Contact Us</a>
    </header>